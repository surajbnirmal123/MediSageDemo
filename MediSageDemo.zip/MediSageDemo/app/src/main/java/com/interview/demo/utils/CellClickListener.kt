package com.interview.demo.utils

import com.interview.demo.model.ItemModel

interface CellClickListener {
    fun onCellClickListener(item: ItemModel)
}
