package com.interview.demo.model

data class ItemModel(val userId: Int, val id: Int, val title: String, val body: String)
