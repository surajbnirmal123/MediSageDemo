package com.interview.demo.view.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.interview.demo.databinding.ItemBinding
import com.interview.demo.model.ItemModel
import com.interview.demo.utils.CellClickListener

class MainAdapter(private val cellClickListener: CellClickListener) : RecyclerView.Adapter<MainViewHolder>() {

    var items = mutableListOf<ItemModel>()

    fun setItemList(itemModels: List<ItemModel>) {
        this.items = itemModels.toMutableList()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainViewHolder {
        val inflater = LayoutInflater.from(parent.context)

        val binding = ItemBinding.inflate(inflater, parent, false)
        return MainViewHolder(binding)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: MainViewHolder, position: Int) {
        val item = items[position]
        holder.binding.tvTitle.text = item.title
        holder.binding.tvBody.text = item.body
        holder.binding.tvId.text = "Id:- ${item.id}"
        holder.binding.tvUserid.text = "UserId:- ${item.userId}"
        holder.itemView.setOnClickListener {
            cellClickListener.onCellClickListener(item)
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }
}

class MainViewHolder(val binding: ItemBinding) : RecyclerView.ViewHolder(binding.root) {

}