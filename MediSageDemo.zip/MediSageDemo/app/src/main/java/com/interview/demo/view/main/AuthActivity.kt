package com.interview.demo.view.main

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.interview.demo.AuthInterface
import com.interview.demo.viewmodel.AuthViewModel
import com.interview.demo.data.database.AppDataBase
import com.interview.demo.data.repository.UserRepository
import com.interview.demo.databinding.AuthActivityBinding
import com.interview.demo.modelfactory.UserViewModelFactory
import com.interview.demo.utils.hide
import com.interview.demo.utils.openActivity
import com.interview.demo.utils.show
import com.interview.demo.utils.toast

class AuthActivity : AppCompatActivity(), AuthInterface {
    private lateinit var binding: AuthActivityBinding
    private lateinit var factory: UserViewModelFactory
    private lateinit var appDataBase: AppDataBase
    private lateinit var repository: UserRepository
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = AuthActivityBinding.inflate(layoutInflater)
        appDataBase = AppDataBase(this)
        repository = UserRepository(appDataBase)
        factory = UserViewModelFactory(repository)
        val authViewModel = ViewModelProvider(this, factory)[AuthViewModel::class.java]
        binding.authViewModel = authViewModel
        setContentView(binding.root)
        authViewModel.authInterface = this
    }

    override fun onProgressStart() {
        binding.progressBar.show()
    }

    override fun onSuccess() {
        openActivity(MainActivity::class.java) {

        }
    }
   override fun onMessage(message: String?) {
       toast(message!!)
    }

    override fun onFailure(message: String) {
        toast(message)
        binding.progressBar.hide()
    }

    override fun onSetEmailError(message: String?) {
        binding.etEmail.error = message
    }
    override fun onSetPasswordError(message: String?) {
        binding.etPassword.error = message
    }
}