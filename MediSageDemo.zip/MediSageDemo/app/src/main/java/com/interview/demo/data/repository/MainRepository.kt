package com.interview.demo.data.repository

class MainRepository constructor(private val retrofitService: RetrofitService) {

    fun getAllPosts() = retrofitService.getAllPosts()
}