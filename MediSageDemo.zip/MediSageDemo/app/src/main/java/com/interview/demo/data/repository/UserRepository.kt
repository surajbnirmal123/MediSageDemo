package com.interview.demo.data.repository

import androidx.lifecycle.LiveData
import com.interview.demo.data.database.AppDataBase
import com.interview.demo.data.database.entity.User

class UserRepository(
    private val appDataBase: AppDataBase
) {

    suspend fun insertUser(user: User) = appDataBase.getUserDao().insertUser(user)

    suspend fun updateUser(user: User) = appDataBase.getUserDao().updateUser(user)

    suspend fun deleteUser(user: User) = appDataBase.getUserDao().deleteUser(user)

    suspend fun deleteUserById(id: Int) = appDataBase.getUserDao().deleteUserById(id)

    suspend fun clearUser() = appDataBase.getUserDao().clearUser()

    fun getAllUsers(): LiveData<List<User>> = appDataBase.getUserDao().getAllUsers()
}